import { useEffect, useState } from "react";
import { infoPersonaStore } from "../../stores/infoPersonaStore";

function SecDatosGenerales() {
  const [infoPersona, setInfoPersona] = useState<infoPersonaProps[]>([]);
  const infoPersonaData = infoPersonaStore((state) => state.data);
  useEffect(() => {
    setInfoPersona(infoPersonaData as infoPersonaProps[]),
      console.log(infoPersona);
  }, [infoPersona, infoPersonaData]);
  return (
    <div
      tabIndex={0}
      className="collapse collapse-arrow border border-base-300 bg-base-200"
    >
      <div className="collapse-title text-xl font-medium">Datos Generales</div>
      <div className="collapse-content">
        <div className="card mt-2">
          <div className="row">
            <div className="col-sm-12 col-md-12 col-lg-6">
              <div className="row">
                <div className="col-sm-6 col-md-5 col-lg-4 font-weight-bold">
                  Nombres
                </div>
                <div className="col score-gen-nombres">{"nombres"}</div>
              </div>
              <div className="row">
                <div className="col-sm-6 col-md-5 col-lg-4 font-weight-bold">
                  Documento
                </div>
                <div className="col score-gen-doc">{"documento"}</div>
              </div>

              <div className="row">
                <div className="col-sm-6 col-md-5 col-lg-4 font-weight-bold">
                  Nacimiento
                </div>
                <div className="col score-gen-fnac">{"nacimiento"}</div>
              </div>
              <div className="row">
                <div className="col-sm-6 col-md-5 col-lg-4 font-weight-bold">
                  Sexo
                </div>
                <div className="col score-gen-sex">{"sexo"}</div>
              </div>

              <div className="row">
                <div className="col-sm-6 col-md-5 col-lg-4 font-weight-bold">
                  Estado Civil
                </div>
                <div className="col score-gen-civil">{"estadocivil"}</div>
              </div>

              <div className="row">
                <div className="col-sm-6 col-md-5 col-lg-4 font-weight-bold">
                  Madre
                </div>
                <div className="col score-gen-madre">{"madre"}</div>
              </div>

              <div className="row">
                <div className="col-sm-6 col-md-5 col-lg-4 font-weight-bold">
                  Padre
                </div>
                <div className="col score-gen-padre">{"padre"}</div>
              </div>

              <div className="row">
                <div className="col-sm-6 col-md-5 col-lg-4 font-weight-bold">
                  Ubigeo Nacimiento
                </div>
                <div className="col score-gen-ubi">{"ubigeonacimiento"}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
/**
interface datosgeneralesProps {
  nombres: string;
  documento: string;
  nacimiento: string;
  sexo: string;
  estadocivil: string;
  madre: string;
  padre: string;
  ubigeonacimiento: string;
}
**/
interface infoPersonaProps {
  data: [];
}
export default SecDatosGenerales;
