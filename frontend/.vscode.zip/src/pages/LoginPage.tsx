import Main from "../layouts/Main";
import Drawer from "../components/organisms/Drawer";

function LoginPage() {
  return (
    <Main>
      <Drawer></Drawer>
    </Main>
  );
}

export default LoginPage;
