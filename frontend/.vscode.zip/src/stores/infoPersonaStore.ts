import { create } from "zustand";

interface infoPersona {
  data: unknown[];
  setInfoPersona: (data: unknown[]) => void;
}

export const infoPersonaStore = create<infoPersona>((set) => ({
  data: [],
  setInfoPersona: (data: unknown[]) => set(() => ({ data })),
}));
