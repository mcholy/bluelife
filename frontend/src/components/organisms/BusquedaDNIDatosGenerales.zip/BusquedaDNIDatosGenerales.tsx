import { useEffect, useState } from "react";
import { infoPersonaStore } from "../../stores/infoPersonaStore";

function SecDatosGenerales() {
  const infoPersonaData = infoPersonaStore((state) => state.data);
  const infoDireccionData = infoPersonaStore((state) => state.data);
  const loading = infoPersonaStore((state) => state.loading);
  const [datosGenerales, setDatosGenerales] = useState<datosGeneralesProps>(
    datosGeneralesDefaultValues
  );
  const [datosDirecciones, setDatosDirecciones] =
    useState<datosDireccionesProps>(datosDireccionesDefaultVales);

  useEffect(() => {
    if (
      typeof infoPersonaData === "object" &&
      "generales" in infoPersonaData!
    ) {
      setDatosGenerales(infoPersonaData.generales as datosGeneralesProps);
    }
  }, [infoPersonaData]);

  useEffect(() => {
    if (
      typeof infoDireccionData === "object" &&
      "direcciones" in infoDireccionData!
    ) {
      setDatosDirecciones(
        infoDireccionData.direcciones as datosDireccionesProps
      );
    }
  }, [infoDireccionData]);

  if (loading)
    return (
      <div className="flex justify-center">
        <div className="stats shadow">
          <div className="stat justify-items-center">
            <div className="stat-title">Cargando...</div>
            <div className="stat-value flex items-center">
              <span className="loading loading-bars loading-xs"></span>
              <span className="loading loading-bars loading-sm"></span>
              <span className="loading loading-bars loading-md"></span>
              <span className="loading loading-bars loading-lg"></span>
            </div>
            <div className="stat-desc">Recopilando información</div>
          </div>
        </div>
      </div>
    );

  return (
    <div>
      <div
        tabIndex={0}
        className="collapse collapse-open collapse-arrow border border-base-300 bg-base-200 w-11/12 mx-auto"
      >
        <div className="collapse-title text-xl font-medium">
          Datos Generales
        </div>
        <div className="collapse-content">
          <div className="card mt-2">
            <div className="row">
              <div className="flex">
                <div className="font-medium">Nombres: </div>
                <div className="px-8">
                  {datosGenerales.nombres} {datosGenerales.paterno}{" "}
                  {datosGenerales.materno}
                </div>
              </div>
              <div className="flex">
                <div className="font-medium">Documento:</div>
                <div className="px-8">{datosGenerales.documento}</div>
              </div>
              <div className="flex">
                <div className="font-medium">Nacimiento:</div>
                <div className="px-8">{datosGenerales.nacimiento}</div>
              </div>

              <div className="flex">
                <div className="font-medium">Sexo: </div>
                <div className="px-8">
                  {datosGenerales.sexo === "2" ? "FEMENINO" : "MASCULINO"}
                </div>
              </div>

              <div className="flex">
                <div className="font-medium">Estado Civil:</div>
                <div className="px-8">{datosGenerales.estado_civil}</div>
              </div>

              <div className="flex">
                <div className="font-medium">Madre:</div>
                <div className="px-8">{datosGenerales.madre}</div>
              </div>
              <div className="flex">
                <div className="font-medium">Padre:</div>{" "}
                <div className="px-8">{datosGenerales.padre}</div>
              </div>
              <div className="flex">
                <div className="font-medium">Ubigeo Nacimiento:</div>
                <div className="px-8">{datosGenerales.lugar_nacimiento}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div
        tabIndex={0}
        className="collapse collapse-open collapse-arrow border border-base-300 bg-base-200 w-11/12 mx-auto"
      >
        <div className="collapse-title text-xl font-medium">Direcciones</div>
        <div className="collapse-content">
          <div className="card mt-2">
            <div className="overflow-x-auto">
              <table className="table">
                {/* head */}
                <thead>
                  <tr>
                    <th>Fecha</th>
                    <th>Tipo</th>
                    <th>Dirección</th>
                    <th>Departamento Provincia Distrito</th>
                  </tr>
                </thead>
                <tbody>
                  {Array.isArray(datosDirecciones.direcciones)
                    ? datosDirecciones.direcciones.map((direccion) => (
                        <tr key={direccion.ubigeo}>
                          <td>{direccion.fecha_data}</td>
                          <td>{direccion.origen_data}</td>
                          <td>{direccion.direccion}</td>
                          <td>{direccion.descripcion_ubigeo}</td>
                        </tr>
                      ))
                    : null}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

interface datosGeneralesProps {
  nombres: string;
  paterno: string;
  materno: string;
  documento: string;
  nacimiento: string;
  sexo: string;
  estado_civil: string;
  madre: string;
  padre: string;
  ubigeonacimiento: string;
  lugar_nacimiento: string;
}

const datosGeneralesDefaultValues: datosGeneralesProps = {
  nombres: "",
  paterno: "",
  materno: "",
  documento: "",
  nacimiento: "",
  sexo: "",
  estado_civil: "",
  madre: "",
  padre: "",
  ubigeonacimiento: "",
  lugar_nacimiento: "",
};
interface datosDireccionesProps {
  direcciones: [
    {
      ubigeo: string;
      descripcion_ubigeo: string;
      direccion: string;
      origen_data: string;
      fecha_data: string;
    }
  ];
}
const datosDireccionesDefaultVales: datosDireccionesProps = {
  direcciones: [
    {
      ubigeo: "",
      descripcion_ubigeo: "",
      direccion: "",
      origen_data: "",
      fecha_data: "",
    },
  ],
};

export default SecDatosGenerales;
